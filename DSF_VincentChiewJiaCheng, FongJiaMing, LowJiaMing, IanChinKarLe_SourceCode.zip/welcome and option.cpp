#include <iostream>
#include <iomanip>
#include <string>
#include <windows.h>

using namespace std;

int main();

int welcome() {

	cout << right << setw(60) << "XXXXX" << endl;
	cout << setw(60) << "  X  " << endl;
	cout << setw(60) << "  X  " << endl;
	cout << setw(60) << "  X  " << endl;
	cout << setw(60) << "  X  " << endl;
	cout << setw(60) << "  X  " << endl;

	//welcome & options
	cout << "\nWelcome to Tokyo Craving's menu" << endl;
	cout << "\n 1. Order entry" << endl;
	cout << " 2. Reporting" << endl;
	cout << " 3. Exit" << endl;

	//input choice
	cout << "Choice: ";

	return 0;
}