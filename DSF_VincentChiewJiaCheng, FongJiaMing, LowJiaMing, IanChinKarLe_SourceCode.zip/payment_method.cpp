#include <iostream>
#include <string>

using namespace std;


int main();

int paymentMethod() {

	char p_method;
	string payment_method = "Invalid";


	while (payment_method == "Invalid") {

		cout << "\nSelect payment method (W = e-Wallet, C = Credit Card, D = Debit Card, M = Cash) :  ";
		cin >> p_method;
		cin.ignore();


		switch (p_method) {

		case 'W':
		case 'w':
			payment_method = "e-Wallet";
			cout << "Payment method : " << payment_method << endl;
			break;
		case 'C':
		case 'c':
			payment_method = "Credit Card";
			cout << "Payment method : " << payment_method << endl;
			break;
		case 'D':
		case 'd':
			payment_method = "Debit Card";
			cout << "Payment method : " << payment_method << endl;
			break;
		case 'M':
		case 'm':
			payment_method = "Cash";
			cout << "Payment method : " << payment_method << endl;
			break;
		default:
			cout << "Invalid Payment Method Selected. " << endl;
			break;
		}
	}


	return 0;
}
