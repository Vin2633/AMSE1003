#include <iostream>
#include <iomanip>
#include <string>

int menu();
int welcome();
int paymentMethod();

using namespace std;

const double DISCOUNT_RATE = 0.10;
const double TAX_RATE = 0.07;

int main() {

	//declaring variables
	int reportNo = 0; //for choosing type of report to open
	int invoiceNo = 1, receiptNo = 1;
	int quantity = 0, total_quantity = 0, choice = 0, item_sold = 0;
	string code = " ", addon, food, payment_method = "Invalid";
	//prices
	double price = 0.0;

	//for calculations
	double subtotal = 0, discounted = 0, service_charge = 0, tax = 0, change = 0, payment_amount = 0, shop_revenue = 0;
	char more = 'Y', p_method = ' ', next_customer = 'Y'; //p_method for user input in form of character
	int order = 1, customer = 1, total_customer = 1;
	double totalPaid = 0;

	//for array 
	int size = 0, capacity = 1;
	string* items = new string[capacity];
	double* prices = new double[capacity];
	int* quantities = new int[capacity];

	//logo, welcome and options display
	welcome();

	//1= order, 2= report, 3= exit
	while (!(cin >> choice) || choice < 1 || choice >3) {
		cin.clear();
		cin.ignore(100, '\n');
		cout << "Invalid choice. Please try again." << endl;
		welcome(); //display menu again
	}

		//continue according to choice
	switch (choice) {

		//for choice 1

	case 1:
		do {
			menu();

			cout << "\nCustomer " << customer << setw(100) << setfill(' ') << right << "20 July 2024" << endl << endl;

			//loop for more orders
			while (more == 'Y' || more == 'y') {

				cout << "Order " << order << endl;
				cout << "Enter item code: ";
				cin >> code; //enter item code



				//assign value according to item code to calculate price & display in bill
				if (code == "F1") {
					food = "Ramen", price = 10;
				}
				else if (code == "F2") {
					food = "Oyakodon", price = 10;
				}
				else if (code == "F3") {
					food = "porridge", price = 10;
				}
				else if (code == "F4") {
					food = "Japanese Curry", price = 10;
				}
				else if (code == "B1") {
					food = "Green Tea", price = 5;
				}
				else if (code == "B2") {
					food = "Milk Tea", price = 5;
				}
				else if (code == "B3") {
					food = "Juice", price = 5;
				}
				else if (code == "B4") {
					food = "Cola", price = 5;
				}
				else if (code == "D1") {
					food = "Takoyaki", price = 7;
				}
				else if (code == "D2") {
					food = "Sushi", price = 7;
				}
				else if (code == "D3") {
					food = "Tempura Shrimp", price = 7;
				}
				else if (code == "D4") {
					food = "Onigiri", price = 7;
				}
				else {
					cout << endl;
					cout << setw(75) << setfill('*') << "" << endl;
					cout << setw(63) << setfill(' ') << "INVALID CODE(CODE IS CASE-SENSITIVE). PLEASE TRY AGAIN" << endl;
					cout << setw(75) << setfill('*') << "" << endl;

					continue; //skip the loop and prompt for code again
				}

				cout << endl << "Quantity: ";

				while (!(cin >> quantity) || (quantity < 1))
				{
					cin.clear();
					cin.ignore(100, '\n');
					cout << "Invalid quantity. Please try again." << endl;
				}

				if (size == capacity) {
					capacity *= 4;

					string* itemList = new string[capacity];
					double* priceList = new double[capacity];
					int* quantityList = new int[capacity];

					for (int i = 0; i < size; i++) {
						itemList[i] = items[i];
						priceList[i] = prices[i];
						quantityList[i] = quantities[i];
					}

					delete[] items;
					items = itemList;
					delete[] prices;
					prices = priceList;
					delete[] quantities;
					quantities = quantityList;

				}

				items[size] = food;
				prices[size] = price;
				quantities[size] = quantity;

				subtotal += prices[size] * quantities[size];
				total_quantity += quantities[size];

				size++;

				cout << endl << "Add-on? ";
				cin.ignore();
				getline(cin, addon);

				cout << endl << "Subtotal: RM " << fixed << setprecision(2) << subtotal << endl << setw(30) << setfill('-') << "" << endl;

				cout << setfill(' ') << "Anymore order? (Y/N): ";
				cin >> more;

				while (more != 'Y' && more != 'y' && more != 'N' && more != 'n')
				{
					cin.ignore(100, '\n');
					cin.clear();
					cout << "Invalid action. Please try again." << endl;
					cout << setfill(' ') << "Anymore order? (Y/N): ";
					cin >> more;
				}

				cout << endl << endl;

				cin.ignore();
				order++;
			}

			if (more == 'N' || more == 'n') {
				cout << "Invoice:" << endl << endl;

				//calculations for promotion
				if (total_quantity >= 3) {
					discounted = subtotal * DISCOUNT_RATE;
				}
				else {
					discounted = 0;
				}

				double serviceCharge = subtotal * 0.10; // 10 % service charge
				double tax = subtotal * TAX_RATE; //7% tax 
				double totalPayable = subtotal - discounted + serviceCharge + tax;


				//PRINT THE INVOICE
				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
				cout << "Tokyo Cravings" << endl;
				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;

				cout << "Invoice No: " << invoiceNo << endl;
				cout << setw(60) << setfill('-') << "" << endl;

				for (int i = 0; i < size; i++) {
					cout << left << setw(30) << setfill(' ') << items[i] << " " << quantities[i] << " x RM " << fixed << setprecision(2) << prices[i] << "\tRM " << fixed << setprecision(2) << (quantities[i] * prices[i]) << endl;
				}

				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
				cout << "Add-on : " << addon << endl;

				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
				cout << "Subtotal\t\t\t RM " << fixed << setprecision(2) << subtotal << endl;
				cout << "Discount (10%)\t\t\t-RM " << fixed << setprecision(2) << discounted << endl;
				cout << "Service Charge (10%)\t\t+RM " << fixed << setprecision(2) << serviceCharge << endl;
				cout << "Tax(7%) \t\t\t+RM " << fixed << setprecision(2) << tax << endl;
				cout << setw(60) << setfill('-') << "" << endl;
				cout << setfill(' ');
				cout << "Total Payable:\t\t\tRM " << fixed << setprecision(2) << totalPayable << endl;
				cout << setw(60) << setfill('-') << "" << endl;
				cout << setfill(' ');

				paymentMethod();

				cout << "\nEnter payment amount : RM ";

				while (!(cin >> payment_amount) || (payment_amount < 0))//execute cin >> payment_amount and check if type and value is valid
				{
					cin.clear();
					cin.ignore(100, '\n');
					cout << "Invalid quantity. Please try again." << endl;
					cin >> payment_amount;
				}

				change = payment_amount - totalPayable;

				totalPaid = payment_amount;

				while (change < 0) {
					cout << "Insufficient amount paid. Please pay the remaining amount : RM " << change * (-1) << endl;
					cout << "Enter payment amount : RM ";
					cin >> payment_amount;
					totalPaid += payment_amount;
					change = payment_amount + change;
					cout << setw(60) << setfill('-') << "" << setfill(' ') << "" << endl;
				}

				cout << "\nReceipt:" << endl << endl;

				//receipt

				//PRINT THE RECEIPT
				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
				cout << "Tokyo Cravings" << endl;
				//cout << companyPhone << endl;
				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;

				cout << "Receipt No: " << receiptNo << endl;
				cout << setw(60) << setfill('-') << "" << endl;

				for (int i = 0; i < size; i++) {
					cout << left << setw(30) << setfill(' ') << items[i] << " " << quantities[i] << " x RM " << fixed << setprecision(2) << prices[i] << "\tRM " << fixed << setprecision(2) << (quantities[i] * prices[i]) << endl;
				}

				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
				cout << "Add-on : \t\t\t" << addon << endl;

				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
				cout << "Subtotal\t\t\t RM " << fixed << setprecision(2) << subtotal << endl;
				cout << "Discount (10%)\t\t\t-RM " << fixed << setprecision(2) << discounted << endl;
				cout << "Service Charge (10%)\t\t+RM " << fixed << setprecision(2) << serviceCharge << endl;
				cout << "Tax(7%) \t\t\t+RM " << fixed << setprecision(2) << tax << endl;

				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
				cout << "Total Payable:\t\t\tRM " << fixed << setprecision(2) << totalPayable << endl;

				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
				cout << "Payment Amount\t\t\tRM " << totalPaid << endl;
				cout << "Change\t\t\t\tRM  " << change << endl;

				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
				cout << "Thank you for your visit. Please come again." << endl;
				cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;


				shop_revenue += totalPayable;
				item_sold += total_quantity;//for reporting function's total item sold

				cout << "\nContinue to next customer?(Y/N):";
				cin >> next_customer;

				while (next_customer != 'Y' && next_customer != 'y' && next_customer != 'N' && next_customer != 'n') {
					cout << "Invalid action. Please try again" << endl;
					cout << "\nContinue to next customer?(Y/N):";
					cin >> next_customer;

				}

				if (next_customer == 'Y' || next_customer == 'y') { //update all values for next customer

					customer++;
					order = 1;
					subtotal = 0;
					payment_amount = 0;
					more = 'Y';
					total_customer++;
					payment_method = "Invalid";
					change = 0;
					totalPayable = 0;
					total_quantity = 0;
					totalPaid = 0;
					invoiceNo++;
					receiptNo++;
					size = 0;


					delete[] quantities;
					delete[] prices;
					delete[] items;

					// Reinitialize size and capacity for new customer
					size = 0;
					capacity = 1;

					// Reset memory for next customer
					quantities = new int[capacity];
					prices = new double[capacity];
					items = new string[capacity];

				}

				else if (next_customer == 'N' || next_customer == 'n') {

					cout << endl;
					welcome();
					while (!(cin >> choice) || choice < 1 || choice >3) {
						cin.clear();
						cin.ignore(100, '\n');
						cout << "Invalid choice. Please try again." << endl;
						welcome(); //display menu again
					}

					if (choice == 1) {
						cout << "System is closed. Please restart system to order again." << endl;
					}

					else if (choice == 2) { //for choice 2
						cout << "\nChoose 1 for daily report, Choose 2 for monthly report: ";
						while (!(cin >> reportNo) || reportNo < 1 || reportNo >3) {
							cin.clear();
							cin.ignore(100, '\n');
							cout << "Invalid option. Please try again." << endl;
							cout << "\nChoose 1 for daily report, Choose 2 for monthly report: ";
						}

						if (reportNo == 1) {
							cout << "\nDaily Report" << endl;
							cout << setw(45) << setfill('-') << "" << setfill(' ') << endl;

							cout << "Number of customers today\t: " << total_customer << endl;
							cout << "Shop revenue today\t\t: RM " << shop_revenue << endl;
							cout << "Total items sold today\t\t: " << item_sold << endl;

							cout << setw(45) << setfill('-') << "" << setfill(' ') << endl;
						}
						else if (reportNo == 2) {
							cout << "\nMonthly Report" << endl;
							cout << setw(45) << setfill('-') << "" << setfill(' ') << endl;

							cout << "Number of customers this month\t: " << total_customer << endl;
							cout << "Shop revenue this month\t\t: RM " << shop_revenue << endl;
							cout << "Total items sold this month\t: " << item_sold << endl;

							cout << setw(45) << setfill('-') << "" << setfill(' ') << endl;
						}

					}
					else if (choice == 3) {	//for choice 3
						cout << "Exiting......" << endl;
						cout << "Thank you for using Tokyo Craving's menu, have a nice day!" << endl;
					}

				}

			}

		} while (next_customer == 'Y' || next_customer == 'y');

		break;

	case 2:
		total_customer = 0;//initialize customer count to 0 because no one ordered yet

		cout << "\nChoose 1 for daily report, Choose 2 for monthly report: " << endl;

		cin >> reportNo;

		if (reportNo == 1) {
			cout << "\nDaily Report" << endl;
			cout << setw(45) << setfill('-') << "" << setfill(' ') << endl;

			cout << "Number of customers today\t: " << total_customer << endl;
			cout << "Shop revenue today\t\t: RM " << shop_revenue << endl;
			cout << "Total items sold today\t\t: " << item_sold << endl;

			cout << setw(45) << setfill('-') << "" << setfill(' ') << endl;
		}
		else if (reportNo == 2) {
			cout << "\nMonthly Report" << endl;
			cout << setw(45) << setfill('-') << "" << setfill(' ') << endl;

			cout << "Number of customers this month\t: " << total_customer << endl;
			cout << "Shop revenue this month\t\t: RM " << shop_revenue << endl;
			cout << "Total items sold this month\t: " << item_sold << endl;

			cout << setw(45) << setfill('-') << "" << setfill(' ') << endl;
		}
		else {
			cout << "Invalid option" << endl;
		}
		break;

	case 3:
		cout << "Exiting......" << endl;
		cout << "Thank you for using Tokyo Craving's menu, have a nice day!" << endl;
		break;


	default:
		cout << "Invalid action" << endl;
		break;

	}
	//clear memory before exiting
	delete[] quantities;
	delete[] prices;
	delete[] items;

	return 0;

}
