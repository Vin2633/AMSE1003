#include <iostream>
#include <iomanip>

using namespace std;

int main();

int menu() {


	//diaply menu
	cout << "\n\nWelcome to Tokyo Craving!\nThis is our Menu!" << endl;
	cout << left << setfill('*');
	cout << "\n---------------------------------------------------------------------------" << endl;
	cout << "\t\t\t\t~Menu~" << endl;
	cout << "---------------------------------------------------------------------------" << endl;
	cout << setw(20) << "Food" << setw(20) << "\tBeverages" << setw(20) << "\tSide Dish" << endl;
	cout << setw(20) << ".Ramen            F1" << setw(20) << "\t.Green Tea       B1" << setw(20) << "\t.Takoyaki        D1" << endl;
	cout << setw(20) << ".Oyakodon         F2" << setw(20) << "\t.Milk Tea        B2" << setw(20) << "\t.Sushi           D2" << endl;
	cout << setw(20) << ".Porridge         F3" << setw(20) << "\t.Juice           B3" << setw(20) << "\t.Tempura Shrimp  D3" << endl;
	cout << setw(20) << ".Japanese Curry   F4" << setw(20) << "\t.Cola            B4" << setw(20) << "\t.Onigiri         D4" << endl;
	cout << setw(40) << "\nSpecial Promotion: Buy 3 food items in total for a 10% DISCOUNT!" << endl;
	cout << "---------------------------------------------------------------------------" << endl;
	cout << "Price: Food is RM10 each; Drinks are RM5 each and Side Dishes are RM7 each!" << endl;
	cout << "---------------------------------------------------------------------------" << endl;

	return 0;
}